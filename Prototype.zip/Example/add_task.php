<?php
include('header.php');

// Redirect if user is not admin
if(isset($_SESSION['ROLE']) && $_SESSION['ROLE'] != '1'){
    header('location:news.php');
    die();
}

// Include database connection
require('db.php');

// Fetch users with rank 2 from the database
$sql = "SELECT id, username FROM admin_user WHERE role = 2";
$result = mysqli_query($con, $sql);

// Initialize an array to store user options for the dropdown
$userOptions = array();

// Check if any users found
if(mysqli_num_rows($result) > 0) {
    // Generate dropdown options dynamically
    while($row = mysqli_fetch_assoc($result)) {
        $userOptions[$row['id']] = $row['username'];
    }
} else {
    // No users found, handle accordingly
    echo "No users found";
    exit();
}

// Handle form submission for adding task
if(isset($_POST['submit'])) {
    $userId = $_POST['user_id'];
    $taskDescription = $_POST['task_description'];
    
    // Insert task into the tasks table
    $insertSql = "INSERT INTO tasks (user_id, description) VALUES ($userId, '$taskDescription')";
    $insertResult = mysqli_query($con, $insertSql);
    
    if($insertResult) {
        // Redirect back to user listing page after successful task addition
        header('location:student.php');
        die();
    } else {
        // Error occurred during task addition, handle accordingly
        echo "Error adding task";
    }
}
?>

<div class="container">
    <h2>Add Task</h2>
    <form method="post">
        <div class="form-group">
            <label for="user_id">Select User:</label>
            <select class="form-control" id="user_id" name="user_id" required>
                <option value="">Select User</option>
                <?php
                // Generate dropdown options
                foreach($userOptions as $userId => $username) {
                    echo "<option value='$userId'>$username</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="task_description">Task Description:</label>
            <textarea class="form-control" id="task_description" name="task_description" rows="3" required></textarea>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Add Task</button>
    </form>
</div>

<?php include('footer.php'); ?>
